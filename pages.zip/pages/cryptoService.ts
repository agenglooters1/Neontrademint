
import { Coin } from '../types';
import { SUPPORTED_COINS } from '../constants';

let priceCache: Record<string, { price: number; change: number }> = {};

const getInitialPrice = (symbol: string): number => {
  const seeds: Record<string, number> = {
    BTC: 92000, ETH: 3100, SOL: 140, XRP: 0.6, DOGE: 0.12,
    ADA: 0.5, AVAX: 35, POL: 0.4, LINK: 18,
    SHIB: 0.00002, TRX: 0.12, LTC: 85, UNI: 7, NEAR: 5,
    XLM: 0.11, ATOM: 9, TON: 5, PEPE: 0.000009, XMR: 170
  };
  return seeds[symbol] || 10;
};

export async function fetchLivePrices(): Promise<Coin[]> {
  const ids = SUPPORTED_COINS.map(c => c.id).join(',');
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    const response = await fetch(
      `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true`,
      { signal: controller.signal }
    );
    
    clearTimeout(timeoutId);

    if (!response.ok) throw new Error(`API Status: ${response.status}`);
    
    const data = await response.json();
    
    return SUPPORTED_COINS.map(coin => {
      const coinData = data[coin.id!];
      const price = coinData?.usd ?? priceCache[coin.id!]?.price ?? getInitialPrice(coin.symbol!);
      const change = coinData?.usd_24h_change ?? priceCache[coin.id!]?.change ?? (Math.random() * 4 - 2);
      
      priceCache[coin.id!] = { price, change };

      return {
        ...coin as Coin,
        price,
        change24h: change,
      };
    });
  } catch (error) {
    return SUPPORTED_COINS.map(coin => {
      const cached = priceCache[coin.id!];
      let price = cached?.price || getInitialPrice(coin.symbol!);
      let change = cached?.change || (Math.random() * 4 - 2);

      const direction = Math.random() > 0.5 ? 1 : -1;
      const tick = price * (Math.random() * 0.0005);
      price += direction * tick;
      change += (Math.random() * 0.1 - 0.05);

      priceCache[coin.id!] = { price, change };

      return {
        ...coin as Coin,
        price,
        change24h: change,
      };
    });
  }
}
